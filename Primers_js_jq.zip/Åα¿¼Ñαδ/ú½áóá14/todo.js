$(document).ready(function(e) {

}); // end ready